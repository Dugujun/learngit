# -*- coding:utf-8 -*-
# author: zchong
import logging

# 获取logger实例，如果参数为空则返回root loger
logger = logging.getLogger("rabbr")

# 指定logger输出格式
logging.basicConfig(
    level=logging.INFO,  # 定义输出到文件的log级别，
    format='%(asctime)s %(levelname)5s %(filename)s[line:%(lineno)d][%(thread)s]%(message)s',  # 定义输出log的格式
    datefmt='%m-%d %H:%M:%S'  # 时间
)
console = logging.StreamHandler()  # 定义console handler
# console.setLevel(logging.INFO)  # 定义该handler级别


