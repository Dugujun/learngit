# -*- coding:utf-8 -*- 
# author: zchong

# 休息时间
SELEEP_S = 1

# 任务启动间隔时间
MAX_JOB_S = 90

# 进程数
PROCESS_NUM = 8

# 线程数
THREAD_NUM = 4

# 是否调试模式 True or False
IS_DEBUG = True

# db
database = 'shoppingmall'
# database = "dzdp"

# db url
# DB_URL = "mongodb://localhost:27017/%s" % database
DB_URL = "mongodb://192.168.0.190:27017/%s" % database

# 记录写覆盖
INSERT_OVER = True

#
province_map = {
    "全国": 0,
    "北京": 1,
    "天津": 2,
    "河北": 3,
    "山西": 4,
    "内蒙古": 5,
    "辽宁": 6,
    "吉林": 7,
    "黑龙江": 8,
    "上海": 9,
    "江苏": 10,
    "浙江": 11,
    "安徽": 12,
    "福建": 13,
    "江西": 14,
    "山东": 15,
    "河南": 16,
    "湖北": 17,
    "湖南": 18,
    "广东": 19,
    "广西": 20,
    "海南": 21,
    "重庆": 22,
    "四川": 23,
    "贵州": 24,
    "云南": 25,
    "西藏": 26,
    "陕西": 27,
    "甘肃": 28,
    "青海": 29,
    "宁夏": 30,
    "新疆": 31,
    "香港": 32,
    "澳门": 33,
    "台湾": 34
}
from collections import OrderedDict

province_map = OrderedDict(sorted(province_map.items(), key=lambda t: t[1]))

if __name__ == '__main__':
    print(province_map)
