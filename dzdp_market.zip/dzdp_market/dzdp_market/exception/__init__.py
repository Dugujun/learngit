# -*- coding:utf-8 -*- 
# author: zchong

class CrawlerException(Exception):
    '''
    Custom exception types
    '''
    def __init__(self, msg, url):
        err = 'Url[{}]异常,Msg[{}]'.format(url,msg)
        Exception.__init__(self, err)

class ForbidException(Exception):
    '''
    Custom exception types
    '''
    def __init__(self, msg, url):
        err = 'Url[{}]异常,Msg[{}]'.format(url,msg)
        Exception.__init__(self, err)