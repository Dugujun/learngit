# -*- coding:utf-8 -*- 
# author: zchong

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from logger import logger
import platform
from constant import IS_DEBUG
from user_agent import getAgents
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import json

d = DesiredCapabilities.CHROME
d['loggingPrefs'] = {'performance':'ALL'}


def getBrowser(isDebug=IS_DEBUG, proxyIP=None):
    user_agent = 'user-agent="%s"' % getAgents()
    options = Options()
    options.add_argument(user_agent)
    print(user_agent)
    if (not isDebug) or platform.system() == "Linux":
        logger.info("当前环境,使用Chrome无界面模式")
        options.add_argument('--headless')

    if proxyIP != None:
        logger.info("Chrome使用代理IP[%s]", proxyIP)
        options.add_argument('--proxy-server=http://%s' % proxyIP)
    driver = webdriver.Chrome(chrome_options=options,desired_capabilities=d)
    return driver


def getMobileBrowser(isDebug=IS_DEBUG):
    mobile_emulation = {"deviceName": "Nexus 5X"}
    user_agent = 'user-agent="%s"' % getAgents()
    options = Options()
    options.add_argument(user_agent)
    print(user_agent)
    options.add_experimental_option("mobileEmulation", mobile_emulation)
    if (not isDebug) or platform.system() == "Linux":
        logger.info("当前环境,使用Chrome无界面模式")
        options.add_argument('--headless')
    driver = webdriver.Chrome(chrome_options=options,desired_capabilities=d)
    return driver

# chrome_options = Options()
# # chrome_options.add_argument('--proxy0-server=https://49.85.2.128:31746')
# # chrome_options.add_argument('user-agent="Mozilla/5.0 (iPod; U; CPU iPhone OS 2_1 like Mac OS X; ja-jp) AppleWebKit/525.18.1 (KHTML, like Gecko) Version/3.1.1 Mobile/5F137 Safari/525.20"')
#
# if(platform.system() =="Linux"):
#     loger.info("Linux环境下,使用Chrome无界面模式")
#     chrome_options.add_argument('--headless')
#
# driver = webdriver.Chrome(chrome_options=chrome_options)
#
# driver.maximize_window()        # 全屏
# driver.implicitly_wait(10)
# driver.get("http://www.dianping.com/wuhan/ch10")
# time.sleep(1)
#
# more_button = driver.find_element_by_css_selector("#classfy > a.more.J_packdown")
# more_button.click()
# select_cates = driver.find_elements_by_css_selector("#classfy > a")
# # 获取所有的链接
# links = [(link.get_attribute("href"),link.text) for link in select_cates if link.get_attribute("href").startswith("http")]
#
# print(links)

# for select_cate in select_cates:
#     link = select_cate.get_attribute("href")
#     print(link)
#     links.append(link)


# for link in links:
#     print("准备跳转url[%s]" % link)
#     driver.get(link)
#     pages = driver.find_elements_by_css_selector("body > div.section.Fix.J-shop-search > div.content-wrap > div.shop-wrap > div.page > a")
#     # [page for page in pages ]
#     pageMax = pages[pages.__len__() - 2].text
#     print(int(pageMax))
