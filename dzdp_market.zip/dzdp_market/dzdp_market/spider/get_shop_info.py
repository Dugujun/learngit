# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os


curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from concurrent.futures import ThreadPoolExecutor
from selenium import webdriver
from dzdp_market.getProxies import Browser
from dzdp_market.logger import logger
import datetime
import lxml
from lxml import etree
from urllib import parse
from dzdp_market.mongo import DB
from selenium.webdriver.common.keys import Keys
import threading
import time
import re

# 线程锁
# look = threading.Lock()
# 递归锁
# rlock = threading.RLock()
# 最大并发量
# sem = threading.Semaphore(3)


dao = DB()
db = dao.getDB()

job_table = 'city_market_info'
target_table = 'shop_info'

primary_table = db[job_table]
target_table = db[target_table]

def decodeStat(source):
    if 'star-50' in source:
        return "五星商户"
    elif 'star-45' in source:
        return "准五星商户"
    elif 'star-40' in source:
        return "四星商户"
    elif 'star-35' in source:
        return "准四星商户"
    elif 'star-30' in source:
        return "三星商户"
    elif 'star-25' in source:
        return "准三星商户"
    elif 'star-20' in source:
        return "二星商户"
    elif 'star-15' in source:
        return "准二星商户"
    elif 'star-10' in source:
        return "一星商户"
    elif 'star-5' in source:
        return "准一星商户"
    elif 'star-0' in source:
        return "准一星商户"
    else:
        return ""

def merchant(info,dic):
    if '营业时间' in info:
        work_time = info.replace('\n','')
        primary_table.update_one({'url':dic['url']},{'$set':{'work_time':work_time}})

        return work_time
    elif '距离位置' in info:
        position = info.replace('\n','')
        primary_table.update_one({'url':dic['url']},{'$set':{'position':position}})

        return position
    elif '联系电话' in info:
        phones = info.replace('\n','')
        phone = re.findall('\d+',phones)
        primary_table.update_one({'url':dic['url']},{'$set':{'phone':phone[0]}})
        return phone

def select_class(driver,class_,dic):
    if '全部' in class_:
        for p in range(25):
            driver.find_element_by_tag_name('body').send_keys(Keys.DOWN)
        # 点击全部
        driver.find_element_by_xpath('//*[@id="lego-widget-shopping-mall-nav-000-000"]/div/div/div[1]/div[%s]' % (len(class_)+1)).click()
        time.sleep(1)
        for x in range(20):
            driver.find_element_by_tag_name('body').send_keys(Keys.DOWN)
        # 点击查看全部商店
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="lego-widget-shopping-mall-nav-000-000"]/div/div/div[3]/i').click()
        # 获取店铺
        get_shop(driver,dic)
        primary_table.update_one({'url': dic['url']}, {'$set': {'status': 'complete'}})


def marketOther(driver,start_url,market_url,dic):
    driver.get(start_url)
    time.sleep(1)
    new_url = market_url.replace('www', 'm')
    driver.get(new_url)
    time.sleep(2)
    res = driver.page_source
    html = lxml.etree.HTML(res)
    if 'verify.meituan.com' in driver.current_url or '未连接到互联网' in res or '抱歉！页面无法访问......' in res or '该网页无法正常运作' in res\
        :
        print('访问失败,跳过---->%s,关闭浏览器' % new_url)
        while True:
            if driver:
                driver.close()
            else:
                print('浏览器已关闭')
                break
        return primary_table.update_one({'url': market_url}, {'$set': {'status': 'pause'}})

    else:
        print('获取商场其它信息')
        # 商场营业时间
        work_times = html.xpath(r'//div[@id="lego-widget-shopping-mall-merchant-info-000-000"]/div/div[@class="merchant-info-list"]/p[1]/text()')
        if len(work_times) > 0:
            merchant(work_times[0],dic)
        # 商场距离位置
        positions = html.xpath(r'//div[@id="lego-widget-shopping-mall-merchant-info-000-000"]/div/div[@class="merchant-info-list"]/p[2]/text()')
        if len(positions) > 0:
            merchant(positions[0],dic)
        # 商场联系电话
        phones = html.xpath(r'//div[@id="lego-widget-shopping-mall-merchant-info-000-000"]/div/div[@class="merchant-info-list"]/p[3]/text()')
        if len(phones) > 0:
            merchant(phones[0],dic)
        # 经纬度
        rest = html.xpath(r'/html/body/script[23]/text()')
        if len(rest) != 0:
            strs = parse.unquote(str(rest))
            glat = re.findall(r'"glat":(\d+.\d+)', strs)
            glng = re.findall(r'"glng":(\d+.\d+)', strs)
            print(glat,glng)
            primary_table.update_one({'url':dic['url']},{'$set':{'glat':glat[0]}})
            primary_table.update_one({'url':dic['url']},{'$set':{'glng':glng[0]}})

        # 查看分类店铺
        class_ = html.xpath(r'//div[@class="nav-icon-list vc-flex line-bottom"]/div/div[@class="nav-name"]/text()')
        print(len(class_))
        if len(class_) != 0:
            select_class(driver,class_,dic)
        else:
            print('该商场无店铺,跳过')
            return primary_table.update_one({'url': dic['url']}, {'$set': {'status': 'skip'}})


def get_shop(driver,dic):
    # 下拉
    while True:
        for c in range(20):
            driver.execute_script("window.scrollBy(0,1000)")
            time.sleep(0.5)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        break
    driver.implicitly_wait(2)
    res = driver.page_source
    html = lxml.etree.HTML(res)
    id_list=[]
    idData = html.xpath(r'//div[@class="shop-list-wrap"]/ul[@class="shop-list-content"]/li/a/@*[1]')
    ids = re.findall('\d{6,}',str(idData))
    for id in ids:
        if id not in id_list:
            id_list.append(id)
    print(len(id_list))
    # 有店铺
    if len(id_list) != 0:
        for i in range(1,len(id_list) + 1):
            shopURl = 'http://m.dianping.com/shop/%s' % id_list[i-1]
            names = html.xpath(r'//ul[@class="shop-list-content"]/li[%d]//div[@class="title mb-text-ellipsis-1"]/text()' % i) #店名
            costs = html.xpath(r'//ul[@class="shop-list-content"]/li[%d]//div[@class="info"]/span[@class="avg-price"]/text()' % i)  #人均
            cost = re.findall('\d+',str(costs))
            grades = html.xpath(r'//ul[@class="shop-list-content"]/li[%d]//div[@class="info"]/span[1]/@class' % i) #等级
            floor = html.xpath(r'//ul[@class="shop-list-content"]/li[%d]//div[@class="position"]/text()' % i)  #楼层
            # 空数据处理
            if len(costs) == 0:
                costs.append('-')
            if len(cost) == 0:
                cost.append('-')
            if len(grades) == 0:
                grades.append('-')
            if len(floor) == 0:
                floor.append('-')
            #保存
            try:
                data = {
                    'province': dic['province'],  # 省份
                    'city': dic['city'],  # 城市
                    'cityDistrict': dic['cityDistrict'],  # 商区
                    'tag':dic['tag'],  # 商圈
                    'classify':dic['classify'],  # 分类
                    'marketUrl':dic['url'],
                    'market':dic['name'],
                    'shopName':names[0],
                    'shopUrl':shopURl,
                    'cost':cost[0],
                    'grade':decodeStat(grades[0]),
                    'floor':floor[0],
                    'time':int(time.time()),
                                        }
                logger.info('%s 插入记录[%s]' % (datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S"),data))
                target_table.replace_one({'shopUrl': shopURl}, data, upsert=True)
            except Exception as error:
                print('数据解析异常',error.args)
    dao.updateJob(target_table, dic)


# 启动爬虫函数
def startSpider(driver):
    # tname = threading.current_thread().getName()
    # print('-------%s:\t%s正在执行' % (arg, tname))
    # start_url = 'http://m.dianping.com/shopping/node/mall/shoplist.html?mallid=4548546&query=2-10'
    try:
        while True:
            # 遍历并更新数据库
            datas = dao.getJob(job_table, {})
            if datas == None:
                print('未获取到商场信息')
                break
                # num += 1
                # if num == 3:
                #     break
            if datas['status'] == 'untreated':
                market_url = datas['url']
                # market_id = re.findall(r'/shop/\d+',market_url)
                start_url = 'https://m.dianping.com/'
                print('---即将访问%s---\t链接:%s' % (datas['name'], market_url))
                marketOther(driver,start_url,market_url, datas)
    except Exception as e:
        primary_table.update_one({'url':datas['url']},{'$set':{'status':'untreated'}})
        print('更换ip,重新打开浏览器')
        # 更换代理ip
        new_brewser = Browser()
        new_driver = new_brewser.get_browser()
        startSpider(new_driver)


# 创建多线程
# def startThreading(THREAD_NUM):
#     with look:
#         for i in range(THREAD_NUM):
#             t = threading.Thread(target=startSpider,args=('多线程中',),name='线程%d'%(i+1))
#             print('------>正在启动第%d条线程' % (i + 1))
#             t.start()
#             time.sleep(5)
            # t.join() #非阻塞

def startThreading():
    # 本地ip
    driver = webdriver.Chrome()
    # 代理
    # browser = Browser()
    # driver = browser.get_browser()
    startSpider(driver)
    print('程序执行到这...')


if __name__ == '__main__':
    THREAD_NUM = 4
    with ThreadPoolExecutor(max_workers=THREAD_NUM) as pool:
        for i in range(THREAD_NUM):
            pool.submit(startThreading,)
            time.sleep(1)
            print('启动第[%d]个线程,执行任务' % (i+1))




