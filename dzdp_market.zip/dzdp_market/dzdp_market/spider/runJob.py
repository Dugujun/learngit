# -*- coding:utf-8 -*- 
# author: zchong
from pymongo.errors import PyMongoError
from logger import logger
from chrome_driver import Driver
# from firefox_driver import Driver
from proxy import getAvailableProxyIP


class Job:

    def __init__(self, dao, job_table):
        self.dao = dao
        self.job_table = job_table

        self.driver = Driver()
        self.browser = self.driver.browser
        self.is_permit = True

        # 初始化日志级别
        import logging
        logger.setLevel(logging.DEBUG)

    def find_element_text(self, css_selector, browser=None):
        if browser is None:
            browser = self.browser
        elements = browser.find_elements_by_css_selector(css_selector)
        if len(elements) == 1:
            return elements[0].get_attribute('innerText')
        return ""

    def switchProxyIp(self):
        ip = getAvailableProxyIP()
        self.browser.quit()
        self.driver = Driver(proxy=ip)
        self.browser = self.driver.browser

    def run_job(self, job):
        pass

    def getJob(self, condition):
        return self.dao.getJob(self.job_table, condition)

    def execute(self, condition=None):
        try:
            i = 1

            while self.is_permit:
                job = self.getJob(condition)
                if job is None:
                    logger.info("所有的任务已经完成,退出程序")
                    self.browser.quit()
                    return 0
                if i % 50 == 0:
                    logger.info("更换一下浏览器的UserAgent")
                    self.driver.quit()
                    self.driver = Driver()
                    self.browser = self.driver.browser
                self.run_job(job)
                i = i + 1

            logger.error("任务无法正常进行,退出")
            self.browser.quit()
            return -1

        # 如果是数据库异常 重启数据库
        except PyMongoError as pe:
            logger.error("Mongodb异常,重新连接mongodb,msg[{}],程序按异常退出,".format(str(pe)))
            self.dao.reconnect()
            self.browser.quit()
            return -9

        except Exception as e:
            self.browser.quit()
            logger.error("未知的异常msg[{}],程序按异常退出,".format(str(e)))
            return -9
