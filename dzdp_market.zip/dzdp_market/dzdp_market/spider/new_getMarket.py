# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from selenium import webdriver
from dzdp_market.getProxies import Browser, switchProxyIp
from dzdp_market.mongo import DB
import lxml
from lxml import etree
import re
import threading
import time
import datetime
from logger import logger
import queue
from concurrent.futures import ThreadPoolExecutor



# 线程锁
look = threading.Lock()
rlock = threading.RLock()
# 状态说明
'''
'untreated':'未处理',
'treateding':'处理中',
'complete' : '完成',
'skip' : '无,跳过',
'pause' : '验证码页面',
'error' : '异常'
'''

dao = DB()
db = dao.getDB()
primary_table = db['city_district_web']
target_table = db['city_market_info']
other_table = db['city_noCrawler']



# 判断函数
def judge(driver,dic,start_url,deep):
    driver.get(start_url)
    time.sleep(2)
    rest = driver.page_source
    page = re.findall(r'>(\d+)</a>', rest)
    allUrl = re.findall(r'http://www.dianping.com/shop/\d+', rest)  # 商场url

    # 出现验证码或者ip不能用时,状态改为pause
    if 'verify.meituan.com' in driver.current_url or '未连接到互联网' in rest or '抱歉！页面无法访问......' in rest or '该网页无法正常运作' in rest:
        print('访问失败--->%s' % start_url)
        if deep == 0:  # 区域访问失败时,关闭浏览器,并修改状态为pause
            # driver.close()
            while True:
                if driver:
                    driver.close()
                else:
                    print('浏览器已关闭')
                    break
            return primary_table.update_one({'url': start_url}, {'$set': {'status': 'pause'}})

        if deep == 1:  # 页数访问失败时,关闭浏览器,并另存
            # driver.close()
            while True:
                if driver:
                    driver.close()
                else:
                    print('浏览器已关闭')
                    break
            data = {
                'province': dic['province'],
                'city': dic['city'],
                'cityDistrict': dic['cityDistrict'],
                'url': start_url,
                'status': 'untreated'
            }
            return other_table.insert_one(data)

    # 网页打不开
    elif 'ERR_PROXY_CONNECTION_FAILED' in rest or "运行 Windows 网络诊断" in rest or "检查代理服务器地址" in rest\
            or "ERR_EMPTY_RESPONSE" in rest or "该网页无法正常运作" in rest:
        print('该网页打不开---->%s' % start_url)
        time.sleep(60*60)
        return primary_table.update_one({'url': start_url}, {'$set': {'status': 'pause'}})


    # 该区域无无商场信息的时候,跳过
    elif '没有找到符合条件的商户' in rest:
        print('该区域无商场信息,跳过---->%s' % start_url)
        return primary_table.update_one({'url':start_url},{'$set':{'status':'skip'}})

    # 访问的页面不存在,跳过
    elif '抱歉,页面无法访问' in rest:
        print('页面不存在--->%s' % start_url)
        return primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})

    # 访问的页面异常（未完全加载）
    elif len(page) == 0 and len(allUrl) == 0:
        print('页面未完全加载--->%s' % start_url)
        # time.sleep(60 * 20)
        new_driver = switchProxyIp(driver)
        time.sleep(1)
        return judge(new_driver, dic, start_url, deep)

        # while True:
        #     if driver:
        #         driver.close()
        #     else:
        #         print('浏览器已关闭')
        #         break
        # print('关闭浏览器')
        # return primary_table.update_one({'url': start_url}, {'$set': {'status': 'pause'}})

    # 正常访问时,执行后续操作
    else:
        # if deep == 0:
        print('准备获取页数')
        return getPage(driver,dic,start_url,rest)

    return rest


def getPage(driver,dic,start_url,rest):
    # 获取当前页面的页数
    page = re.findall(r'>(\d+)</a>', rest)
    # 只有一页的情况
    if len(page) == 0:
        print('只有一页')
        page = [1]
    print('页数: %s' % page)
    # 遍历所有的页
    for p in range(1,int(page[-1]) + 1):
        page_url = start_url + 'p' + str(p)
        print('正在获取第%d页---->链接: %s' % (p,page_url))
        print('保存各商场信息')
        if len(page) == 1 or p == 1:
            saveMarketData(dic, driver.page_source)
        else:
            deep = 1
            if p > 1:
                pages = judge(driver,dic,page_url,deep)
                if pages == None:
                    print('页面[%s]出现验证未抓取到数据' % page_url)
                else:
                    saveMarketData(dic, pages)
    return primary_table.update_one({'url': start_url}, {'$set': {'status': 'complete'}})


# 保存商场信息
def saveMarketData(dic,pages):
    url_list = []
    allUrl = re.findall(r'http://www.dianping.com/shop/\d+', pages)  # 商场url
    # 去重
    for marketUrl in allUrl:
        if marketUrl not in url_list:
            url_list.append(marketUrl)
    print(len(url_list))
    html = lxml.etree.HTML(pages)
    # 商场其余信息
    for j in range(1,len(url_list)+1):
        MarketUrl = url_list[j-1]
        names = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tit"]/a/h4/text()' % j)  # 商场名
        grades = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/span/@title' % j)  # 等级
        comments = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/a[1]/b/text()' % j)  # 评论,
        costs = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/a[2]/b/text()' % j)  # 人均消费,
        address = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/span/text()' % j)  # 地址
        qualitys = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[1]/b/text()' % j)  # 质量评分,
        environmentals = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[2]/b/text()' % j)  # 环境评分,
        service = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[3]/b/text()' % j)  # 服务评分,
        classify = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/a[1]/span/text()' % j)  # 分类
        tag = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/a[2]/span/text()' % j)  # 商圈
        # 空数据处理
        if len(names) == 0:
            names.append('-')
        if len(grades) == 0:
            grades.append('-')
        if len(comments) == 0:
            comments.append('-')
        if len(costs) == 0:
            costs.append('-')
        if len(address) == 0:
            address.append('-')
        if len(qualitys) == 0:
            qualitys.append('-')
        if len(environmentals) == 0:
            environmentals.append('-')
        if len(service) == 0:
            service.append('-')
        if len(classify) == 0:
            classify.append('-')
        if len(tag) == 0:
            tag.append('-')
        try:
            data = {
                'province': dic['province'],  # 省份
                'city': dic['city'],  # 城市
                'cityDistrict': dic['cityDistrict'],  # 商区
                'tag': tag[0],  # 商圈
                'classify': classify[0],  # 分类
                'name': names[0],  # 商场名
                'url': MarketUrl,  # 商场的url
                'grade': grades[0],  # 商场等级
                'comment': comments[0],  # 评论数
                'cost': costs[0],  # 人均消费
                'address': address[0],  # 地址
                'quality': qualitys[0],  # 质量评分
                'environment': environmentals[0],  # 环境评分
                'service': service[0],  # 服务评分
                'status': 'untreated',  # 未处理状态
                'updatets': int(time.time())
            }
            print("%s 插入记录[%s]" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), data))
        # 数据库
            target_table.replace_one({'url': MarketUrl}, data, upsert=True)
        except Exception as error:
            print('数据解析异常',error.args)

# 启动爬虫函数
def startSpider(driver):
    # tname = threading.current_thread().getName()
    # print('-------%s:\t%s正在执行' % tname)
    time.sleep(0.2)
    try:
        while True:
            # 获取数据中的信息,并更新状态为处理中
            dic = primary_table.find_one_and_update({'status': 'untreated'}, {'$set': {'status': 'treateding','updatets':int(time.time())}})
            # 判断目标商区状态
            if dic == None:
                print('未获取到区域信息')
                break
                # count += 1
                # if count == 3:
                #     break
                #     # return 0
                # continue
            # 未抓取的状态
            if dic['status'] == 'untreated':
                start_url = dic['url']
                deep = 0  # 控制层数
                print('%s: 即将访问%s--->%s--->%s\t,链接:%s' % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),dic['province'], dic['city'], dic['district'], start_url))
                # 判断
                judge(driver,dic,start_url,deep)
                time.sleep(1)

    except Exception as e:
        print('更换ip,重新打开浏览器')
        primary_table.update_one({'url': dic['url']}, {'$set': {'status': 'untreated'}})
        # 更换代理ip
        new_brewser = Browser()
        new_driver = new_brewser.get_browser()
        startSpider(new_driver)



# # 创建多线程
# def startThreading(THREAD_NUM):
#     with look:
#         for i in range(THREAD_NUM):
#             # 代理ip启动
#             browser = Browser()
#             driver = browser.get_browser()
#             proxies = browser.get_proxies()
#             # 本地ip启动
#             # proxies = "--proxy-server=http://112.64.53.24:4275"
#             # chromeOptions = webdriver.ChromeOptions()
#             # chromeOptions.add_argument(proxies)
#             # driver = webdriver.Chrome(chrome_options=chromeOptions)
#             # driver = webdriver.Chrome()
#             t = threading.Thread(target=startSpider,args=('多线程中',driver),name='线程%d' % (i+1))
#             print('------>正在启动第[%d]条线程' % (i+1))
#             t.start()
#             time.sleep(5)



# def startThreading(THREAD_NUM):
#     print('启动多线程')
#     queues = queue.Queue()
#     for i in range(THREAD_NUM):
#         # 本地
#         # driver = webdriver.Chrome()
#         # 代理
#         browser = Browser()
#         driver = browser.get_browser()
#         t = threading.Thread(target=startSpider,args=('多线程中',driver),name='线程%d' %(i+1))
#         t.daemon = False   #daemon 等于True 程序才退出
#         t.start()
#     for item in range(THREAD_NUM):
#         queues._put(item)
#     queues.join()
#     print('程序执行到这...')




def startThreading():
    # 本地
    browser = Browser()
    driver = browser.get_browser()
    startSpider(driver)
    print('程序执行到这...')



if __name__ == '__main__':
    THREAD_NUM = 1

    with ThreadPoolExecutor(max_workers=THREAD_NUM) as executor:
        for i in range(THREAD_NUM):
            executor.submit(startThreading,)
            time.sleep(1)
            print("启动第[%d]个线程程,开始处理任务" % i)
