# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

import requests
import lxml
from lxml import etree
from dzdp_market.proxy import getAvailableProxyIP
import threading
import time
from dzdp_market.getUserAgent import getAgent
import re
from dzdp_market.mongo import DB
import datetime

# 线程锁
look = threading.Lock()
# 递归锁
rlock = threading.RLock()
# 最大并发量
sem = threading.Semaphore(5)

# 状态说明
'''
'untreated':'未处理',
'treateding':'处理中',
'complete' : '完成',
'skip' : '无,跳过',
'pause' : '验证码页面',
'error' : '异常'
'''

dao = DB()
db = dao.getDB()
# print(db)
primary_table = db.district
target_table = db.marketData
other_table = db.noCrawler


# 判断函数
def judge(dic,start_url,proxies,deep):
    # 开始
    while True:
        header = getAgent()
        time.sleep(2)
        response = requests.get(start_url, headers=header,proxies=proxies)
        page = response.text
        # 可以正常访问时:
        if response.status_code == 200:
            print(response.status_code, '---访问成功')

            # 出现验证时:
            # if 'verify.meituan.com' in response.url:
            if len(page) == 0:
                print('出现验证--->:%s' % response.url)
                if deep == 0:  #区域验证,修改状态
                    primary_table.update_one({'url': start_url}, {'$set': {'status': 'pause'}})

                if deep == 1:  #页数时出现验证,另存

                    data = {
                        'province': dic['province'],
                        'city': dic['city'],
                        'cityDistrict': dic['cityDistrict'],
                        'url': start_url,
                        'status': 'untreated'
                                            }
                    other_table.insert_one(data)

            # 或该区域无商场信息.跳过
            elif '没有找到符合条件的商户' in page:
                print('该商区没有找到商户信息,跳过--->%s' % start_url)
                primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})

            # 执行后续操作
            else:
                if deep == 0:
                    print('准备获取页数')
                    getMarketData(dic, start_url, page, proxies=proxies)
            break

        # 访问的页面不存在时:跳过
        elif response.status_code == 404 and '抱歉！页面无法访问' in page:
            print(response.status_code, '页面不存在--->%s' % start_url)
            primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})
            break

        # ip被封,禁止访问时:
        else:
            print(response.status_code, '---访问失败,准备使用代理ip')
            # 添加代理ip
            new_ip = {'http':'http://%s' % getAvailableProxyIP()}

            # loop = {'http':'http://112.64.53.24:4275'}
            ip = new_ip

            print(ip)
            agent(dic,start_url,ip,deep)
            # judge(dic,start_url,ip,deep)
            break

# 使用代理函数
def agent(dic,start_url,proxies,deep):
    count = 0
    while True:
        header = getAgent()
        try:
            time.sleep(2)
            response = requests.get(start_url, headers=header, proxies=proxies, timeout=5)
            page = response.text
            print(response.status_code)
            if response.status_code == 200:
                print(response.status_code, '---访问成功')

                # 出现验证码
                # if 'verify.meituan.com' in response.url:
                if len(page) == 0:
                    print('出现验证--->:%s' % response.url)
                    if deep == 0:  #区域,修改状态
                        primary_table.update_one({'url': start_url}, {'$set': {'status': 'pause'}})

                    if deep == 1:  #页数,另存
                        data = {
                            'province': dic['province'],
                            'city': dic['city'],
                            'cityDistrict': dic['cityDistrict'],
                            'url': start_url,
                            'status': 'untreated'
                                    }
                        other_table.insert_one(data)

                # 或该区域无商场信息,跳过
                elif '没有找到符合条件的商户' in page:
                    print('该商区没有找到商户信息,跳过--->%s' % start_url)
                    primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})

                # 执行后续操作
                else:
                    if deep == 0:
                        print('准备获取页数')
                        getMarketData(dic, start_url, page, proxies)
                break
            # 访问的页面不存在时:跳过
            elif response.status_code == 404 and '抱歉！页面无法访问' in page:
                print(response.status_code, '页面不存在--->%s' % start_url)
                primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})
                break

            # 访问仍然不成功
            else:
                count += 1
                print(count)
                if count == 10:
                    break
        except:
            print('---请求访问失败,跳过此条链接:%s' % start_url)
            # 将状态改为异常状态 error
            primary_table.update_one({'url': start_url}, {'$set': {'status': 'error'}})
            print('下一个')
            break
    return proxies

# 获取页数
def getMarketData(dic,start_url,page,proxies):
    # 获取当前链接的页数
    pages = re.findall(r'>(\d+)</a>', page)
    if len(pages) == 0:
    # 这是只有一页的情况
        print('只有一页')
        pages = [1]
    print('页数:%s' % pages)
    # 遍历所有页
    for p in range(1,int(pages[-1]) + 1):
        page_url = start_url + 'p' + str(p)
        print('---正在抓取第%d页---链接:%s' % (p,page_url))
        if len(pages) > 1:
            deep = 1
            # 判断
            judge(dic,page_url,proxies,deep)
        print('保存商场信息')
        saveMarketData(dic,page_url,proxies)
        # 函数结束后
        # 将该dic的状态修改为已完成
        primary_table.update_one({'url': start_url}, {'$set': {'status': 'complete'}})

# 保存商场信息
def saveMarketData(dic,page_url,proxies):
    while True:
        url_list = []
        time.sleep(1)
        req = requests.get(page_url,headers=getAgent(),proxies=proxies)
        datas = req.text
        allUrl = re.findall(r'http://www.dianping.com/shop/\d+',datas)#商场url
        # 去重
        for marketUrl in allUrl:
            if marketUrl not in url_list:
                url_list.append(marketUrl)

        print(len(url_list))
        # 商场其它信息
        html = lxml.etree.HTML(req.content.decode("UTF-8"))
        names = html.xpath('//div[@class="tit"]/a/h4/text()')  # 商场名
        grades = html.xpath('//div[@class="comment"]/span/@title')  # 等级
        comments = html.xpath('//div[@class="comment"]/a[1]/b/text()')  # 评论,
        costs = html.xpath('//div[@class="comment"]/a[2]/b/text()')  # 人均消费,
        address = html.xpath('//div[@class="tag-addr"]/span/text()')  # 地址
        qualitys = html.xpath('//span[@class="comment-list"]/span[1]/b/text()')  # 质量评分,
        environmentals = html.xpath('//span[@class="comment-list"]/span[2]/b/text()')  # 环境评分,
        service = html.xpath('//span[@class="comment-list"]/span[3]/b/text()')  # 服务评分,
        classify = html.xpath('//div[@class="tag-addr"]/a[1]/span/text()')  # 分类
        tag = html.xpath('//div[@class="tag-addr"]/a[2]/span/text()')  # 商圈

        a = ['-' for x in range(len(url_list))]
        # 特殊:没有地址的商场
        if len(address) < len(url_list):
            address.extend(['-' for x in range(len(url_list) - len(address))])

        if len(comments) == 0:
            comments.extend(a)
        elif 0 < len(comments) < len(url_list):
            comments.extend([comments[-1] for x in range(len(url_list) - len(comments))])

        if len(costs) == 0:
            costs.extend(a)
        elif 0 < len(costs) < len(url_list):
            costs.extend([costs[-1] for x in range(len(url_list) - len(costs))])

        if len(qualitys) == 0:
            qualitys.extend(a)
        elif 0 < len(qualitys) < len(url_list):
            qualitys.extend([qualitys[-1] for x in range(len(url_list) - len(qualitys))])

        if len(environmentals) == 0:
            environmentals.extend(a)
        elif 0 < len(environmentals) < len(url_list):
            environmentals.extend(
                [environmentals[-1] for x in range(len(url_list) - len(environmentals))])

        if len(service) == 0:
            service.extend(a)
        elif 0 < len(service) < len(url_list):
            service.extend([service[-1] for x in range(len(url_list) - len(service))])

        if len(tag) == 0:
            tag.extend(a)
        elif 0 < len(tag) < len(url_list):
            tag.extend([tag[-1] for x in range(len(url_list) - len(tag))])

        # 将商场各信息保存
        for j, MarketUrl in enumerate(url_list):
            # print( MarketUrl, '\t', names[j], grades[j], comments[j], costs[j],
            #       address[j], qualitys[j],
            #       environmentals[j], service[j])
            data = {
                'province': dic['province'],  # 省份
                'city': dic['city'],  # 城市
                'cityDistrict': dic['cityDistrict'],  # 商区
                'tag': tag[j], # 商圈
                'classify': classify[j], # 分类
                'name': names[j],  # 商场名
                'url': MarketUrl,  # 商场的url
                'grade': grades[j], # 商场等级
                'comment': comments[j],  # 评论数
                'cost': costs[j],  # 人均消费
                'address': address[j],  # 地址
                'quality': qualitys[j],  # 质量评分
                'environment': environmentals[j],  # 环境评分
                'service': service[j] , # 服务评分
                'status' : 'untreated'  #未处理状态
                }
            print("time %s 插入记录[%s]" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),data))
            # 数据库
            target_table.replace_one({'url':MarketUrl},data,upsert=True)
        break



# 启动爬虫函数
def startSpider(args):
    tname = threading.current_thread().getName()
    print('-------%s:\t%s正在执行' % (args, tname))
    time.sleep(0.2)
    count = 0
    while True:
        # 获取数据中的信息,并更新状态为处理中
        dic = primary_table.find_one_and_update({'status': 'untreated'}, {'$set': {'status': 'treateding'}})
        # 判断目标商区状态
        if len(dic) == 0:
            print('未获取到区域信息')
            count += 1
            if count == 3:
                break
        # 未抓取的状态
        if dic['status'] == 'untreated':
            start_url = dic['url']
            proxies = None
            deep = 0  # 控制层数
            print('time:%s: 即将访问%s--->%s--->%s\t,链接:%s' % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),dic['province'], dic['city'], dic['cityDistrict'], start_url))
            # 判断
            print(proxies)
            judge(dic, start_url,proxies,deep)

            print('----->%s执行完毕-----\n' % tname)
            time.sleep(0.1)



# 创建多线程
def startThreading(THREAD_NUM):
    with rlock:
        for i in range(THREAD_NUM):
            t = threading.Thread(target=startSpider,args=('多线程中',),name='线程%d' % (i+1))
            print('------>正在启动第%d条线程' % (i+1))
            time.sleep(5)
            t.start()
            # t.join() #非阻塞


if __name__ == '__main__':
    THREAD_NUM = 1
    startThreading(THREAD_NUM)


