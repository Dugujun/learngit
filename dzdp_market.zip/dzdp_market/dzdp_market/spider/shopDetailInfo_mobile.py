# -*- coding:utf-8 -*- 
# author: zchong
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

import traceback
from runJob import Job
from mongo import db
import time
from concurrent.futures import ThreadPoolExecutor
import collections
from logger import logger
from constant import *
from exception import CrawlerException
import re
import json

dao = db()
job_table = "shop_info"
target_table = "shop_detail"
condition = {}


def decodeStat(source):
    if 'star-50' in source:
        return "五星商户"
    elif 'star-45' in source:
        return "准五星商户"
    elif 'star-40' in source:
        return "四星商户"
    elif 'star-35' in source:
        return "准四星商户"
    elif 'star-30' in source:
        return "三星商户"
    elif 'star-25' in source:
        return "准三星商户"
    elif 'star-20' in source:
        return "二星商户"
    elif 'star-15' in source:
        return "准二星商户"
    elif 'star-10' in source:
        return "一星商户"
    elif 'star-5' in source:
        return "准一星商户"
    elif 'star-0' in source:
        return "准一星商户"
    else:
        return ""

class ShopDetailInfo(Job):
    def __init__(self, dao, job_table):
        super().__init__(dao, job_table)

    def getTargerTable(self, province):
        return _target_table.format(province_map[province])

    def getHttpStatus(self,browser):
        for responseReceived in browser.get_log('performance'):
            try:
                response = json.loads(responseReceived['message'])['message']['params']['response']
                if response['url'] == browser.current_url:
                    return (response['status'], response['statusText'])
            except:
                pass
        return None

    def getShopName(self, url):
        self.browser.get(url)
        names = self.browser.find_elements_by_css_selector(".shop-name")
        # 正常情况  返回查找到的name值
        if len(names) != 0:
            return names[0].get_attribute('innerText')

        # 不正常的情况下 再试一次
        logger.error("Url[%s]未找到name信息,再试一次", url)
        self.browser.get(url)
        names = self.browser.find_elements_by_css_selector(".shop-name")
        if len(names) != 0:
            return names[0].get_attribute('innerText')

        # # 再试一次,还是没有name,检查错误页面
        # loger.error("Url[%s]未找到name信息,检查错误页面", url)
        #
        # if "错误信息：请求错误" in self.browser.page_source:
        #     loger.error("Url[%s]指向的页面可能确实不存在,抛出异常,跳过执行", url)
        #     raise RuntimeError('Url[%s]确实没有店铺信息,跳过' % url)

        # IP被封的情况
        # 1 跳转到验证码页面   https://verify.meituan.com/v2/web/general_page
        current_url = self.browser.current_url
        if "verify.meituan.com" in current_url:
            logger.error("Url[%s]指向了验证码页面", url)
            self.switchProxyIp()
            return self.getShopName(url)
            # self.isPermit = False
            # raise RuntimeError('Url[%s]指向了验证码页面' % url)

        # 2 提示错误信息 body > div.not-found > div > div.not-found-right > p.not-found-words1
        divs = self.browser.find_elements_by_css_selector("div.not-found-right > p.not-found-words1")
        for d in divs:
            text = d.get_attribute('innerText')
            if "userIp" in text:
                logger.error("Url[%s]直接返回了异常界面", url)
                # self.isPermit = False
                # raise RuntimeError('Url[%s]指向了验证码页面' % url)
                self.switchProxyIp()
                return self.getShopName(url)

        shops = self.browser.find_elements_by_css_selector("div.not-found-right > div.not-found-words")
        if "抱歉！页面暂时无法访问" in self.browser.page_source and len(shops) > 0  and len(names) == 0:
            logger.error("页面[%s]可能不存在,跳过跳过该条记录", url)
            return "商户不存在"

        if "对不起，您要访问的页面没有找到!" in self.browser.page_source and "秒后自动跳转到首页" in self.browser.page_source:
            logger.error("页面[%s]可能不存在,跳过跳过该条记录", url)
            return "商户不存在"

        respense = self.getHttpStatus(self.browser)[0]
        if respense == 200 and len(names) == 0:
            logger.error("页面[%s]可能不是餐饮商户,跳过跳过该条记录", url)
            return "非餐饮商户"


        # 其他情况没遇到过,跳过吧
        logger.error("Url[%s]指向的页面异常未知,抛出异常,跳过执行", url)
        raise RuntimeError('Url[%s]指向的页面异常未知,跳过' % url)

    def run_job(self, job):
        try:
            # target_table = self.getTargerTable(job["province"])
            url = job["url"]
            m_url = url.replace('www.', 'm.')
            # 获取url
            name = self.getShopName(m_url)
            record = collections.OrderedDict()
            record["url"] = url
            record["m_url"] = m_url
            record["province"] = job["province"]
            record["city"] = job["city"]
            # 网页请求状态
            record['response'] = self.getHttpStatus(self.browser)

            if name == "商户不存在" or name == "非餐饮商户":
                pass
            else:
                _classify = self.browser.find_elements_by_css_selector("div.J_breadcrumb > div > a:nth-child(1)")
                record["classify"] = _classify[0].get_attribute('innerText') if len(_classify) > 0 else ""

                _tag = self.browser.find_elements_by_css_selector("div.J_breadcrumb > div > a:nth-child(3)")
                record["tag"] = _tag[0].get_attribute('innerText') if len(_tag) > 0 else ""

                _type = self.browser.find_elements_by_css_selector("div.J_breadcrumb > div > a:nth-child(5)")
                record["type"] = _type[0].get_attribute('innerText') if len(_type) > 0 else ""

                _smalltype = self.browser.find_elements_by_css_selector("div.J_breadcrumb > div > a:nth-child(7)")
                record["smalltype"] = _smalltype[0].get_attribute('innerText') if len(_smalltype) > 0 else ""

                record["name"] = name
                record["address"] = self.find_element_text(".J_address > div > div > a")
                record["tel"] = self.find_element_text(".J_phone > div > div > div > a")

                # 星级
                _star = self.browser.find_elements_by_css_selector(
                    "div.J_baseinfo > div > div.shopPicBg > p > span:nth-child(1)")
                record['star'] = _star[0].get_attribute("class") if len(_star) > 0 else ""
                record["star"] = decodeStat(record["star"])

                # 评论数
                _review_num = self.browser.find_elements_by_css_selector("span.itemNum")
                record["review_num"] = _review_num[0].get_attribute("textContent") if len(_review_num) == 1 else ""

                # 人均消费
                _mean_price = self.browser.find_elements_by_css_selector(
                    "div.J_baseinfo > div > div.shopPicBg > p > span.price")
                record["mean_price"] = _mean_price[0].get_attribute("textContent") if len(_mean_price) == 1 else "-"

                # record['desc'] = self.find_element_text('.desc')
                # 评论
                comments = self.browser.find_elements_by_css_selector("div.J_baseinfo > div > div.desc > span")
                _comments = map(lambda x: x.text, comments)
                record["desc"] = ",".join(_comments)

                # 外卖网址
                _waimai_url = self.browser.find_elements_by_css_selector("div.J_orders > div.cutway1 > a")
                record["waimai_url"] = _waimai_url[0].get_attribute("href") if len(_waimai_url) == 1 else ""

                _business_hours = self.browser.find_elements_by_css_selector("div.J_otherinfo > div > div > div")
                if len(_business_hours) > 0:
                    record["business_hours"] = _business_hours[0].get_attribute('innerText').strip()

                # 判断店铺是否关闭
                _isClose = self.browser.find_elements_by_css_selector("div.upload_error")
                if len(_isClose) > 0:
                    record["is_close"] = _isClose[0].text
                else:
                    record["is_close"] = ""

                # 推荐菜
                dishs = collections.OrderedDict()
                dishItems = self.browser.find_elements_by_css_selector("a.dishItem")
                if len(dishItems) != 0:
                    for dishItem in dishItems:
                        dishName = dishItem.find_element_by_class_name("dishName").text
                        _goodUp = dishItem.find_elements_by_class_name("recommendInfo")
                        goodUp = _goodUp[0].text if len(_goodUp) > 0 else ""
                        # goodUp = dishItem.find_element_by_class_name("recommendInfo").text
                        dishs[dishName] = goodUp
                else:
                    dishItems = self.browser.find_elements_by_css_selector("a.dishesPan > span.singeDishName")
                    for dishItem in dishItems:
                        dishName = dishItem.text
                        dishs[dishName] = ''

                record['dishs'] = dishs

                # 榜单
                _list = self.browser.find_elements_by_css_selector("div.commonRank")
                record["bangdan"] = _list[0].get_attribute("textContent").strip().replace('\n', '') if len(
                    _list) == 1 else ""

                # 团购促销
                tuan = self.browser.find_elements_by_css_selector("div.tuan-list > a:nth-child(1)")
                _tuan = map(lambda x: x.get_attribute("textContent").strip().replace('\n', ''), tuan)
                record["tuan"] = ";".join(_tuan)

                # 品牌图片
                _img_src = self.browser.find_elements_by_css_selector("div.J_baseinfo > div > a > img")
                img_src = _img_src[0].get_attribute("src") if len(_img_src) == 1 else ""
                if img_src != "" and "p0.meituan.net/searchscenerec/" not in img_src and "p1.meituan.net/searchscenerec/" not in img_src and "p2.meituan.net/searchscenerec/" not in img_src and "www.dpfile.com" not in img_src:
                    record["img_src"] = img_src
                else:
                    record["img_src"] = ""

                # 获取经纬度
                self.browser.get(m_url + "/map")
                location = (re.findall(r'"shopLat":(.+?),"shopLng":([0-9/.]+?),"', self.browser.page_source))
                record["location"] = location[0].__repr__() if len(location) > 0 else ""

            # 记录查询完毕插入记录
            record["updatets"] = int(time.time())
            record["status"] = "untreated"
            record["pid"] = job["_id"]
            logger.info("插入Record记录[%s]", record)
            self.dao.insertRecord(target_table, record)
            if name == "商户不存在":
                self.dao.updateJob(job_table, job, status="non-existent")
            elif name == "非餐饮商户":
                self.dao.updateJob(job_table, job, status="non-meishi")
            else:
                self.dao.updateJob(job_table, job)
            logger.info("任务[%s],执行完成,休息[%d]秒 ZZZ...", job, SELEEP_S)
            time.sleep(SELEEP_S)

        except CrawlerException as ce:
            logger.error("任务[%s]-Url[%s]执行失败,异常信息[%s]", job_table, job["url"], traceback.format_exc())
            import sys
            pos = __file__ + ":" + str(sys._getframe().f_lineno)
            self.dao.writeErrorLog(job_table, job, pos, ce)

        except Exception as e:
            logger.error("任务[%s]-Url[%s]执行失败,异常信息[%s]", job_table, job["url"], traceback.format_exc())
            import sys
            pos = __file__ + ":" + str(sys._getframe().f_lineno)
            self.dao.writeErrorLog(job_table, job, pos, e)
            time.sleep(SELEEP_S)
            raise e




def run(dao):
    while True:
        job = ShopDetailInfo(dao=dao, job_table=job_table)
        res = job.execute(condition=condition)
        if res == 0:
            break


from utils import getProvinceCode
import sys

if __name__ == '__main__':
    # job = {
    # "_id" : "5b72747aeaa9b22d942bb362",
    # "province" : "广西",
    # "city" : "柳州",
    # "url" : "http://m.dianping.com/shop/74098332",
    # "status" : "untreated",
    # "updatets" : 1529756000
    # }
    #
    # run = ShopDetailInfo(dao=dao, job_table=job_table)
    # run.run_job(job)

    (province, code) = getProvinceCode(sys.argv)
    # THREAD_NUM = 1
    if code == 0:
        condition = {}
    else:
        condition['province'] = province
    print("启动线程数[%d]抓取省份/直辖市[%s]数据" % (THREAD_NUM, province))

    with ThreadPoolExecutor(max_workers=THREAD_NUM) as executor:
        for i in range(THREAD_NUM):
            executor.submit(run, dao)
            time.sleep(1)
            print("启动第[%d]个线程程,开始处理任务" % i)


