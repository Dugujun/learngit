# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from selenium import webdriver
import lxml
from lxml import etree
import requests
from getUserAgent import getAgent
from mongo import DB
from proxy import getAvailableProxyIP
import threading
import time
import re
from mobile_driver import MobileDriver


# 线程锁
look = threading.Lock()
# 递归锁
rlock = threading.RLock()
# 最大并发量
sem = threading.Semaphore(3)


browsers = MobileDriver()
drive = browsers.browser

dao = DB()
db = dao.getDB()
primary_table = db.marketData
target_table = db.shop_info

def decodeStat(source):
    if 'star-50' in source:
        return "五星商户"
    elif 'star-45' in source:
        return "准五星商户"
    elif 'star-40' in source:
        return "四星商户"
    elif 'star-35' in source:
        return "准四星商户"
    elif 'star-30' in source:
        return "三星商户"
    elif 'star-25' in source:
        return "准三星商户"
    elif 'star-20' in source:
        return "二星商户"
    elif 'star-15' in source:
        return "准二星商户"
    elif 'star-10' in source:
        return "一星商户"
    elif 'star-5' in source:
        return "准一星商户"
    elif 'star-0' in source:
        return "准一星商户"
    else:
        return ""







def getid(new_url,dic):

    # drive = webdriver.Chrome()
    classItems = {"10": "美食", "25": "电影演出赛事", "30": "休闲娱乐", "60": "酒店", "50": "丽人", "15": "K歌", "45": "运动健身",
                  "35": "周边游", "70": "亲子", "55": "结婚", "20": "购物", "95": "生活服务", "80": "生活服务", "75": "学习培训", "65": "爱车",
                  "85": "医疗健康", "90": "家居", "40": "宴会", "33954": "榛果民宿"}
    count = 0
    for p in classItems.keys():
        id_list = []
        workUrl = new_url.replace('-10','-%s'%p)
        print('正在获取%s类,链接:%s' %(classItems[p],workUrl))
        c = 0
        while True:
            header = getAgent()
            time.sleep(1)
            response = requests.get(workUrl, headers=header)
            print(response.status_code)
            c += 1
            if response.status_code == 200:
                print('成功,准备抓取店铺')
                time.sleep(1)
                drive.get(workUrl)
                break

            # elif response.status_code == 403:
            #     print('ip被封,使用代理ip')
            #     proxip = {"http":"http://%s" %getAvailableProxyIP()}
            #     break

            if c == 10:
                print('请求失败,访问下一类')
                break

        # 拉到底
        while True:
            for i in range(20):
                drive.execute_script("window.scrollBy(0,1000)")
                time.sleep(0.25)
            drive.execute_script("window.scrollTo(0, document.body.scrollHeight)")
            break
        res = drive.page_source
        html = lxml.etree.HTML(res)
        idData = html.xpath(r'//div[@class="shop-list-wrap"]/ul[@class="shop-list-content"]/li/a/@*[1]')
        ids = re.findall('\d{6,}',str(idData))
        names = html.xpath(r'//div[@class="title-wrap mb-flexbox"]/div/text()') #店名
        costs = html.xpath(r'//div[@class="shop-list-wrap"]/ul[@class="shop-list-content"]/li/a/div[@class="shop-item-r mb-flex-1"]/div[@class="info"]/span[@class="avg-price"]/text()')  #人均
        cost = re.findall('\d+',str(costs))
        grades = html.xpath(r'//ul[@class="shop-list-content"]/li/a/div[@class="shop-item-r mb-flex-1"]/div[@class="info"]/span[1]/@class') #等级
        floor = html.xpath(r'//div[@class="shop-list-wrap"]/ul[@class="shop-list-content"]/li/a/div[@class="shop-item-r mb-flex-1"]/div[@class="position"]/text()')  #楼层
        print(len(ids),len(names))
        for id in ids:
            if id not in id_list:
                id_list.append(id)
        if len(id_list) == 0:
            print('该商场没有%s类店铺'%classItems[p])
            count += 1

        if count == 19:
            print('该商场没有店铺')
            db.marketData.update_one({'url': dic['url']}, {'$set': {'status': 'complete'}})
            break
        # 有店铺
        if len(id_list) != 0:

            if len(cost) == 0:
                cost.extend(['-' for x in range(len(id_list))])
            elif len(cost) < len(id_list):
                cost.extend([cost[-1] for x in range(len(id_list) - len(cost))])
                print('填充')

            if len(grades) == 0:
                costs.extend(['-' for x in range(len(id_list))])
            elif len(grades) < len(id_list):
                costs.extend([grades[-1] for x in range(len(id_list) - len(grades))])

            if len(floor) == 0:
                floor.extend(['-' for x in range(len(id_list))])
            elif len(floor) < len(id_list):
                floor.extend([floor[-1] for x in range(len(id_list) - len(floor))])
                print('填充')
        #保存
        print(len(id_list),len(names),len(cost),len(grades),len(floor))
        for i in range(len(id_list)):
            data = {
                'province': dic['province'],  # 省份
                'city': dic['city'],  # 城市
                'cityDistrict': dic['cityDistrict'],  # 商区
                'tag':dic['tag'],  # 商圈
                'classify':dic['classify'],  # 分类
                'marketUrl':dic['url'],
                'market':dic['name'],
                'class':classItems[p],
                'shopName':names[i],
                'shopUrl':r'http://www.dianping.com/shop/%s'%id_list[i],
                'cost':cost[i],
                'grade':decodeStat(grades[i]),
                'floor':floor[i]
                                    }
            # DB.db.target_table.insert_one(data)
            target_table.replace_one({'url': r'http://www.dianping.com/shop/%s'%ids[i] }, data, upsert=True)



# 启动爬虫函数
def startSpider(arg):
    tname = threading.current_thread().getName()
    print('-------%s:\t%s正在执行' % (arg, tname))
    start_url = 'http://m.dianping.com/shopping/node/mall/shoplist.html?mallid=4548546&query=2-10'
    num = 0
    while True:
        # 遍历并更新数据库
        datas = primary_table.find_one_and_update({'status': 'untreated'}, {'$set': {'status': 'treateding'}})
        if len(datas) == 0:
            print('未获取到商场信息')
            num += 1
            if num == 3:
                break
        if datas['status'] == 'untreated':
            market_id = re.findall(r'\d+', datas['url'])
            print(market_id)
            new_url = re.sub(r'\d{6,}', market_id[0], start_url)
            # new_url =
            print('---即将访问%s---\t链接:%s' % (datas['name'], new_url))
            getid(new_url, datas)
            db.marketData.update_one({'url': datas['url']}, {'$set': {'status': 'complete'}})
            print('----->%s执行完毕-----\n' % tname)


# 创建多线程
def startThreading(THREAD_NUM):
    with rlock:
        for i in range(THREAD_NUM):
            t = threading.Thread(target=startSpider,args=('多线程中',),name='线程%d'%(i+1))
            print('------>正在启动第%d条线程' % (i + 1))
            time.sleep(5)
            t.start()
            # t.join() #非阻塞


if __name__ == '__main__':
    THREAD_NUM = 1
    startThreading(THREAD_NUM)




