# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录

import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)


import sys
from dzdp_market.getProxies import Browser
import lxml
from lxml import etree
from dzdp_market.mongo import DB
import time
import re
import threading
import datetime
from selenium import webdriver
from concurrent.futures import ThreadPoolExecutor

dao = DB()
db = dao.getDB()
target_table = db['city_market_info']
primary_table = db['city_noCrawler']


# 线程锁
look = threading.Lock()
# 递归锁
rlock = threading.RLock()
# 最大并发量
sem = threading.Semaphore(5)


# 状态说明
'''
'untreated':'未处理',
'treateding':'处理中',
'complete' : '完成',
'skip' : '无,跳过',
'pause' : '验证码页面',
'error' : '异常'
'''

def get_data(driver,dic,start_url):
    url_list = []
    driver.get(start_url)
    time.sleep(2)
    res = driver.page_source
    page = re.findall(r'>(\d+)</a>', res)
    allUrl = re.findall(r'http://www.dianping.com/shop/\d+', res)  # 商场url
    # 出现验证码或者ip不能用时,状态改为pause
    if 'verify.meituan.com' in driver.current_url or '未连接到互联网' in res or '抱歉！页面无法访问......' in res or '该网页无法正常运作' in res:
        print('访问失败--->%s' % start_url)
        while True:
            if driver:
                driver.close()
            else:
                print('浏览器已关闭')
                break
        return primary_table.update_one({'url':start_url},{'$set':{'status':'pause'}})

    elif '没有找到符合条件的商户' in res:
        print('该页没有商户,跳过--->%s'%start_url)
        return primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})

    # 访问的页面不存在,跳过
    elif '抱歉,页面无法访问' in res:
        print('页面不存在--->%s' % start_url)
        return primary_table.update_one({'url': start_url}, {'$set': {'status': 'skip'}})
    elif len(page) == 0 and len(allUrl) == 0:
        print('加载异常')
        time.sleep(2)
        while True:
            if driver:
                driver.close()
            else:
                print('浏览器已关闭')
                break

    else:
        print('准备抓取数据信息')
        urls = re.findall(r'http://www.dianping.com/shop/\d+',res)
        for marketUrl in urls:
            if marketUrl not in url_list:
                url_list.append(marketUrl)
        html = lxml.etree.HTML(res)
        for j in range(1, len(url_list) + 1):
            MarketUrl = url_list[j - 1]
            names = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tit"]/a/h4/text()' % j)  # 商场名
            grades = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/span/@title' % j)  # 等级
            comments = html.xpath(
                '//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/a[1]/b/text()' % j)  # 评论,
            costs = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="comment"]/a[2]/b/text()' % j)  # 人均消费,
            address = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/span/text()' % j)  # 地址
            qualitys = html.xpath(
                '//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[1]/b/text()' % j)  # 质量评分,
            environmentals = html.xpath(
                '//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[2]/b/text()' % j)  # 环境评分,
            service = html.xpath(
                '//div[@id="shop-all-list"]/ul/li[%d]//span[@class="comment-list"]/span[3]/b/text()' % j)  # 服务评分,
            classify = html.xpath(
                '//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/a[1]/span/text()' % j)  # 分类
            tag = html.xpath('//div[@id="shop-all-list"]/ul/li[%d]//div[@class="tag-addr"]/a[2]/span/text()' % j)  # 商圈
            # 空数据处理
            if len(names) == 0:
                names.append('-')
            if len(grades) == 0:
                grades.append('-')
            if len(comments) == 0:
                comments.append('-')
            if len(costs) == 0:
                costs.append('-')
            if len(address) == 0:
                address.append('-')
            if len(qualitys) == 0:
                qualitys.append('-')
            if len(environmentals) == 0:
                environmentals.append('-')
            if len(service) == 0:
                service.append('-')
            if len(classify) == 0:
                classify.append('-')
            if len(tag) == 0:
                tag.append('-')
            try:
                data = {
                    'province': dic['province'],  # 省份
                    'city': dic['city'],  # 城市
                    'cityDistrict': dic['cityDistrict'],  # 商区
                    'tag': tag[0],  # 商圈
                    'classify': classify[0],  # 分类
                    'name': names[0],  # 商场名
                    'url': MarketUrl,  # 商场的url
                    'grade': grades[0],  # 商场等级
                    'comment': comments[0],  # 评论数
                    'cost': costs[0],  # 人均消费
                    'address': address[0],  # 地址
                    'quality': qualitys[0],  # 质量评分
                    'environment': environmentals[0],  # 环境评分
                    'service': service[0],  # 服务评分
                    'status': 'untreated',  # 未处理状态
                    'updatets':int(time.time())
                }
                print("%s 插入记录[%s]" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), data))
                # 数据库
                target_table.replace_one({'url': MarketUrl}, data, upsert=True)
                primary_table.update_one({'url': start_url}, {'$set': {'status': 'complete'}})

            except Exception as error:
                print('数据解析异常', error.args)

def startSpider(driver):
    try:
        while True:
            dic = primary_table.find_one_and_update({'status': 'untreated'}, {'$set': {'status': 'treateding'}})
            if dic == None:
                print('未获取到区域信息')
                break

            if dic['status'] == 'untreated':
                print('即将访问%s--->%s--->%s,链接:%s' % (dic['province'], dic['city'], dic['district'], dic['url']))
                start_url = dic['url']
                get_data(driver,dic, start_url)

    except Exception as e:
        primary_table.update_one({'url':dic['url']},{'$set':{'status':'untreated'}})
        print('更换ip,重新打开浏览器')
        # 更换代理ip
        new_brewser = Browser()
        new_driver = new_brewser.get_browser()
        startSpider(new_driver)


# def startThreading(THREAD_NUM):
#     with rlock:
#         for i in  range(THREAD_NUM):
#             # 代理ip启动
#             browser = Browser()
#             driver = browser.get_browser()
#             proxies = browser.get_proxies()
#             t = threading.Thread(target=startSpider, args=('多线程中',driver,proxies), name='线程%d' % (i + 1))
#             print('------>正在启动第%d条线程' % (i + 1))
#             time.sleep(5)
#             t.start()


# import queue
# def startThreading(THREAD_NUM):
#     print('启动多线程')
#     queues = queue.Queue()
#     for i in range(THREAD_NUM):
#         # 本地
#         driver = webdriver.Chrome()
#         # 代理
#         # browser = Browser()
#         # driver = browser.get_browser()
#         t = threading.Thread(target=startSpider,args=('多线程中',driver),name='线程%d' %(i+1))
#         t.daemon = False   #daemon 等于True 程序才退出
#         t.start()
#     for item in range(THREAD_NUM):
#         queues._put(item)
#     queues.join()
#     print('程序执行到这...')




def startThreading():
    # 本地
    driver = webdriver.Chrome()
    # 代理
    # browser = Browser()
    # driver = browser.get_browser()
    startSpider(driver)
    print('程序执行到这...')




if __name__ == '__main__':
    THREAD_NUM = 4

    with ThreadPoolExecutor(max_workers=THREAD_NUM) as executor:
        for i in range(THREAD_NUM):
            executor.submit(startThreading,)
            time.sleep(1)
            print("启动第[%d]个线程程,开始处理任务" % i)


