# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

import requests
import lxml
from lxml import etree
import re
import time
from getUserAgent import getAgent
from mongo import DB


dao = DB()
db = dao.getDB()


def get_region(url,province,cityName,w_url):
    # 开始访问
    time.sleep(1)
    header = getAgent()
    response = requests.get(url,headers=header)
    if response.status_code != 200:
        print('%d,请求失败,---准备再次请求' % response.status_code)
        count = 0
        while True:
            time.sleep(1)
            response = requests.get(url,headers=header)
            count += 1
            if response.status_code == 200:
                break
            if count == 10:
                print('出现异常,跳过访问此城市')
                break
    print('%d,--请求成功--!' % response.status_code)
    page = response.content.decode("UTF-8")
    html = lxml.etree.HTML(page)
    region_name = html.xpath(r'//div[@class="box shopallCate"][2]/dl/dt/a/text()')
    region_urls = html.xpath(r'//div[@class="box shopallCate"][2]/dl/dt/a/@href')
    # 没有区域的情况
    if len(region_name) == 0 or len(region_urls) == 0:
        print('---此城市可能无商区---\t链接:%s' % url)
        # 将此城市本身也作为区域保存
        #将此城市作为区域
        new_url = re.sub(r'/ch10','ch20/g119',w_url)
        data = {
            'province': province,
            'city': cityName,
            'district': cityName,
            'districtId': None,
            'url': new_url,
            'status':'untreated',
            'undatets':int(time.time())
        }
        # dzdp.city_district.insert_one(data)
    else:
    #处理获取的商区信息
        for i in range(len(region_urls)):
            region_id = re.findall(r'ch0/(\w+)',region_urls[i])
            region_list = re.findall(r'/\w+/ch0/\w+',region_urls[i])
            region_url = re.sub(r"ch0/",'ch20/g119',region_list[0]) #重新构建区域的url
            data = {
                'province': province,
                'city': cityName,
                'district': region_name[i],
                'districtId': region_id[0],
                'url': 'http://www.dianping.com'+region_url,
                'status': 'untreated',
                'undatets': int(time.time())
            }
            # dzdp.city_district.insert_one(data)
            print(province,cityName,region_name[i],region_id[0],'http://www.dianping.com'+region_url)

if __name__ == '__main__':
    res = db.city_mobile.find({'status':'untreated'})
    #遍历
    for data in res:
        city_url = data['source_url']
        province = data['province']
        city_name = data['city']
        w_url = data['w_url']
        print('即将访问%s,链接:%s' % (city_name,city_url))
        time.sleep(1)
        get_region(city_url,province,city_name,w_url)


