# -*- coding:utf-8 -*-
# author: zhangeh


import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)


import numpy as np
from mongo import DB
import time
from logger import logger
import collections
import pandas as pd


db = DB()


job_table = 'district'
target_table = 'district'
condition = {}




def getdata():
    dates = []
    rows = db.findRecordsByParm(job_table, {})
    print(len(rows))
    if len(rows) > 0:
        i = 1
        for row in rows:
            print(i)
            # print(row)
            # row['dates'] = time.strftime("%Y-%m-%d %X", time.gmtime(row['time']))
            row['dates'] = time.strftime("%Y-%m-%d", time.gmtime(row['time']))
            dates.append(row['dates'])
            print(row['dates'])
            # if row['dates'] == "2018-10-13":
            #     print("**************")
            # else:
            #     db.updateJob(target_table, row, status="untreated")
            # logger.info("job任务[%s]", row)
            i += 1
    else:
        print("--------------------------------------")
    return dates






if __name__ == '__main__':
    dates = getdata()
    print('?????????????')
    print(list(set(dates)))









