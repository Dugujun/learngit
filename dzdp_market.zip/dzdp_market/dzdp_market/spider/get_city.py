# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)



# 获取所有的城市
from selenium import webdriver
import time
import lxml
from lxml import etree
from mongo import DB

dao = DB()

target_table = 'city'
browser = webdriver.Chrome()
time.sleep(1)
browser.get('http://www.dianping.com/citylist')
html = browser.page_source
myetree = lxml.etree.HTML(html)
url_list = myetree.xpath('//div[@class="findHeight"]/a/@href')  #链接
name_list = myetree.xpath('//div[@class="findHeight"]/a/text()') #城市名
#插入数据库中的名为city集合
for i,city_name in enumerate(name_list):
    record = {'city':city_name,'url':'http:' + url_list[i] + '/ch20/g119','status':'untreated','updatets':int(time.time())}
    print(record)
    dao.insertRecord(target_table,record)

browser.quit()






