# -*- coding:utf-8 -*-
# author: zchong

from pymongo import MongoClient
from time import time
from constant import MAX_JOB_S, DB_URL, INSERT_OVER, database
from exception import CrawlerException, ForbidException
from logger import logger



# def link_mongodb():
#     # 连接数据库
#     client = MongoClient('192.168.0.190', 27017)
#     db = client.dzdp
#     print('初始化数据库')
#     return db
# if __name__ =='__mian__':
#     print(link_mongodb())


class DB:
    def __init__(self):
        print("初始化数据库...")
        self.uri = DB_URL
        self.conn = MongoClient(self.uri)
        self.db = self.conn[database]  # 连接数据库，没有则自动创建
        # self.set = db.city #使用test_set集合，没有则自动创建
        # info = {}
        # info['city'] = 'wuhan'
        # info['classify'] = '自助餐'
        # info['url'] = 'http://www.dianping.com/wuhan/ch10/g111'
        # info['status'] = 'untreated'
        # self.set.insert(info)

    def reconnect(self):
        self.conn.close()
        self.conn = MongoClient(self.uri)
        self.db = self.conn[database]

    def getDB(self):
        return self.db

    def __del__(self):
        self.conn.close()
        print("关闭数据库")

    def getJob(self, name, _condition):
        current_time = int(time())
        valid_time = current_time - MAX_JOB_S

        condition = {'status': 'untreated', 'updatets': {'$lt': valid_time}}

        condition.update(_condition)
        update = {'$set': {'updatets': current_time, 'status': 'working'}}
        table = getattr(self.db, name)
        job = table.find_one_and_update(condition, update)
        return job

    def insertRecord(self, name, record):
        url = record['url']
        table = getattr(self.db, name)
        # 存在记录跳过更新
        if not INSERT_OVER:
            rows = table.count({"url": url})
            if rows == 1:
                logger.info("url[%s]记录存在，跳过更新" % url)
                return

        table.replace_one({"url": url}, record, upsert=True)

    def insertOneRecord(self, name, record):
        table = getattr(self.db, name)
        table.insert_one(record)

    def replaceRecord(self, name, record, parm):
        table = getattr(self.db, name)
        # 存在记录跳过更新
        if not INSERT_OVER:
            rows = table.count(parm)
            if rows == 1:
                logger.info("url[%s]记录存在，跳过更新" % url)
                return

        table.replace_one(parm, record, upsert=True)


    def findRecordsByPid(self, name, pid):
        table = getattr(self.db, name)
        res = table.find({"pid": pid})
        return list(res)

    def findRecordsByParm(self, name, parm):
        table = getattr(self.db, name)
        res = table.find_one(parm)
        return res

    def updateJob(self, name, job, status="completed"):
        current_time = int(time())
        table = getattr(self.db, name)
        table.update({"_id": job["_id"]}, {'$set': {"updatets": current_time, "status": status}})

    def removeJob(self, name, parm):
        table = getattr(self.db, name)
        table.remove(parm)

    def writeErrorLog(self, name, job, position, e):
        record = {};
        record['position'] = position
        record['url'] = job["url"]
        record["exception"] = str(e);
        record["updatets"] = int(time())
        self.db.error_log.insert(record)
        if isinstance(e, CrawlerException):
            logger.warn("job-url[%s],为自定义异常,跳过任务", job["url"])
            self.updateJob(name, job, status="skip")
        elif isinstance(e, ForbidException):
            logger.warn("job-url[%s],禁止访问", job["url"])
            self.updateJob(name, job, status="forbid")
        else:
            logger.warn("job-url[%s],其他异常", job["url"])
            self.updateJob(name, job, status="pause")
