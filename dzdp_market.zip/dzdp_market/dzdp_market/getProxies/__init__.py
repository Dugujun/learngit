from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
from dzdp_market.proxy import getAvailableProxyIP
from getUserAgent import getAgent
from logger import logger
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import json
import platform
from constant import IS_DEBUG

d = DesiredCapabilities.CHROME
d['loggingPrefs'] = {'performance':'ALL'}


class Browser:
    def __init__(self, proxy = None):
        print('初始化浏览器....')
        chromeOptions = webdriver.ChromeOptions()
        user_agent = 'user-agent="%s"' % getAgent()
        chromeOptions.add_argument(user_agent)
        print(user_agent)
        if (not IS_DEBUG) or platform.system() == "Linux":
            logger.info("当前环境,使用Chrome无界面模式")
            chromeOptions.add_argument('--headless')

        if proxy != None:
            # self.proxies = "--proxy-server=http://112.64.53.24:4275"
            self.proxies = "--proxy-server=http://%s" % proxy
            print(self.proxies)
            chromeOptions.add_argument(self.proxies)

        self.driver = webdriver.Chrome(chrome_options=chromeOptions, desired_capabilities=d)
        # logger.info("driver初始化完成,跳转点评主页")
        # self.driver.get("http://www.dianping.com/wuhan")



    def get_browser(self):
        return self.driver

    # def get_proxies(self):
    #     return self.proxies

    def quit(self):
        self.driver.quit()

    def __del__(self):
        self.driver.quit()
        # print('关闭浏览器')


def switchProxyIp(browser):
    ip = getAvailableProxyIP()
    browser.quit()
    driver = Browser(proxy=ip)
    return driver.get_browser()

