# -*- coding:utf-8 -*- 
# author: zchong
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from logger import logger
import platform
from constant import IS_DEBUG
from logger import logger
from user_agent import getAgents
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import json

d = DesiredCapabilities.CHROME
d['loggingPrefs'] = {'performance':'ALL'}

class Driver:

    def __init__(self,proxy=None):
        user_agent = 'user-agent="%s"' % getAgents()
        options = Options()
        options.add_argument(user_agent)
        print(user_agent)
        if (not IS_DEBUG) or platform.system() == "Linux":
            logger.info("当前环境,使用Chrome无界面模式")
            options.add_argument('--headless')

        if proxy != None:
            proxy = proxy.strip()
            logger.info("Chrome使用代理IP[%s]", proxy)
            options.add_argument('--proxy-server=http://%s' % proxy)
        self.browser = webdriver.Chrome(chrome_options=options,desired_capabilities=d)
        logger.info("driver初始化完成,跳转点评主页")
        self.browser.get("http://www.dianping.com/")

    # def getWebElementByUrl(self,url):
    #     self.browser.get(url)

    def getDriver(self):
        return self.browser

    def quit(self):
        self.browser.quit()

    def __del__(self):
        self.browser.quit()


