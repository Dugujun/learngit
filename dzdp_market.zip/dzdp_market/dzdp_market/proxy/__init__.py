# -*- coding:utf-8 -*-
# 添加上级目录到包检索目录
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

# 获取IP
from urllib import request
from logger import logger
import time
import json
import re


def getAvailableProxyIP():
    for i in range(10):
        ip = getProxyIP()
        if ip == None:
            logger.info("未获取到IP，程序休息中。。。")
            time.sleep(60 * 30)
        else:
            return ip
    return None

# 添加到白名单
def addWhiteList(ip):
    url = "http://web.http.cnapi.cc/index/index/save_white?neek=41100&appkey=7318b62c2fd283cf715c367f0c4485ad&white=" + ip
    res = request.urlopen(url).read().decode('utf-8')
    logger.info("添加白名单返回信息" + res)

# 获取IP
def getProxyIP():
    res = ""
    test_res = ""
    try:
        # url = "http://webapi.http.zhimacangku.com/getip?num=1&type=1&pro=310000&city=0&yys=0&port=1&time=1&ts=0&ys=0&cs=0&lb=1&sb=0&pb=45&mr=1&regions="
        url = "http://webapi.http.zhimacangku.com/getip?num=1&type=1&pro=0&city=0&yys=0&port=1&pack=30405&ts=0&ys=0&cs=0&lb=1&sb=0&pb=4&mr=2&regions="
        res = request.urlopen(url).read().decode('utf-8')
        ip = res.split(":")
        if len(ip) == 2:
            return res.replace("\r\n","")
        else:
            j = json.loads(res)
            # ip需要添加白名单
            if j['code'] == 113:
                l = re.findall(r'\d+.\d+.\d+.\d+',j['msg'])
                logger.info('需要将IP地址[%s],添加到白名单',l[0])
                addWhiteList(l[0])
                return getAvailableProxyIP()
            if j['code'] == 111:
                logger.info("请求太频繁")
                time.sleep(10)
                return getAvailableProxyIP()
            if j['code'] == 116:
                logger.info("套餐今日已到达上限")
                time.sleep(60*60)
                return None
    except Exception as e:
        logger.info("无法获取有效代理IP,代理服务器返回信息[%s],验证服务器返回信息[%s]",res,test_res)
        return None

if __name__ == '__main__':
    ip = getAvailableProxyIP()
    print(ip)

