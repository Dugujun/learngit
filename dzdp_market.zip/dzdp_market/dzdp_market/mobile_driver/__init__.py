# -*- coding:utf-8 -*- 
# author: zchong
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from logger import logger
import platform
# from constant import IS_DEBUG
from logger import logger


IS_DEBUG = True


class MobileDriver:

    def __init__(self,proxy=None):
        options = Options()
        mobile_emulation = {"deviceName": "iPhone 6"}
        options.add_experimental_option("mobileEmulation", mobile_emulation)
        if (not IS_DEBUG) or platform.system() == "Linux":
            logger.info("当前环境,使用Chrome无界面模式")
            options.add_argument('--headless')
        self.browser = webdriver.Chrome(chrome_options=options)
        self.browser.get("http://m.dianping.com/wuhan")
    # def getWebElementByUrl(self,url):
    #     self.browser.get(url)

    def getDriver(self):
        return self.browser

    def quit(self):
        self.browser.quit()

    def __del__(self):
        self.browser.quit()


if __name__ == '__main__':
    driver = MobileDriver()
    driver.getDriver()

